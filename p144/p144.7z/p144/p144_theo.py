"""
from matplotlib.patches import Ellipse
import matplotlib as mpl
#matplotlib inline
from matplotlib import pyplot as plt

mean = [ 0 ,  0]
width = 10
height = 20
angle = 0
ell = mpl.patches.Ellipse(xy=mean, width=width, height=height, angle = 180+angle, edgecolor='r', fc='None')
fig, ax = plt.subplots()

ax.add_patch(ell)
ax.set_aspect('equal')
ax.autoscale()

#plt.plot([0.0, 1.4],[10.1, -9.6])


"""
def scalar(a,b):
    print("scalar:", (a[0]*b[0]+a[1]*b[1])/(a[0]**2+a[1]**2)**(1/2)/(b[0]**2+b[1]**2)**(1/2))

# 1st
x_0, y_0 = 1.4, -9.6
x_a, y_a = 0, 10.1

for i in range(10000):
    print("-"*10,"Iteration",i,"-"*10)
    a_x, a_y = x_0-x_a, y_0-y_a
    #b_x, b_y = x_0-x_b, y_0-y_b

    n_x, n_y = 1, y_0/(4*x_0)

    # becareful with the sign
    b_y_pos = (n_y*(a_x+n_y*a_y) + (a_x**2*n_y**2+a_y**2-2*a_x*a_y*n_y)**(1/2))/(1+n_y**2)
    b_x_pos = a_x + n_y*(a_y-b_y_pos)

    b_y_neg = (n_y*(a_x+n_y*a_y) - (a_x**2*n_y**2+a_y**2-2*a_x*a_y*n_y)**(1/2))/(1+n_y**2)
    b_x_neg = a_x + n_y*(a_y-b_y_neg)

    if abs(1-abs(b_y_pos/b_x_pos)/abs(a_y/a_x)) > abs(1-abs(b_y_neg/b_x_neg)/abs(a_y/a_x)):
        b_y = b_y_pos
        b_x = b_x_pos
    else:
        b_y = b_y_neg
        b_x = b_x_neg

    #print("b_x,b_y",b_x,b_y)
    #print("b_x,b_y", x_0 - b_x, y_0 - b_y)
    #print(b_x ** 2 + b_y ** 2, a_x ** 2 + a_y ** 2)

    #plt.plot([x_0, x_0 - b_x], [y_0, y_0 - b_y], 'r')  # reflection
    #scalar([a_x, a_y], [n_x, n_y])
    #scalar([b_x, b_y], [n_x, n_y])

    n = (-8*x_0*(a_x+n_y*a_y)+2*b_y*(4*x_0*n_y-y_0))/(4*(a_x**2+a_y**2)-3*b_y**2)

    B_y = y_0+n*b_y
    B_x_neg = -((100 - B_y**2)**(1/2))/2 # becareful with the sign
    B_x_pos = ((100 - B_y ** 2) ** (1 / 2)) / 2  # becareful with the sign
    if abs(1-abs(b_y/b_x)/abs((y_0-B_y)/(x_0-B_x_pos))) > abs(1-abs(b_y/b_x)/abs((y_0-B_y)/(x_0-B_x_neg))):
        B_x = B_x_neg
    else:
        B_x = B_x_pos

    if abs(B_x) <= 0.01 and B_y >0:
        print("Found",i+1)
        exit(0)

    #print(n)
    #print(B_x, B_y)

    #plt.plot([x_0, B_x], [y_0, B_y],'b')

    x_a, y_a = x_0, y_0
    x_0, y_0 = B_x, B_y


#plt.show()

